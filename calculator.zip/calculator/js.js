function insrt(num){
    $('.result').val($('.result').val() + num);
}
function eql(){
    $('.result').val(eval($('.result').val()));
}
function c(){
    $('.result').val('');
}
function back(){
   value = $('.result').val();
   $('.result').val(value.substring(0,value.length - 1));
}








